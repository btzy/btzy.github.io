// O(V+E)
#define MAX_N 1000000
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;

// input:
int n=MAX_N; // num vertices
vector<int> adjlist[MAX_N]; // adjlist (directed)
// output:
int scc_index[MAX_N]; // all nodes in same scc has same index
// if iterate scc by index from largest to smallest,
// it is a topological ordering
// note: can be modified to return each component when found

int tj_index[MAX_N];
int tj_lowlink[MAX_N];
bool tj_os[MAX_N];
int tj_curr;
stack<int> tj_st;
int tj_scc_ct;
void strongconnect(int node){
    tj_index[node]=tj_lowlink[node]=tj_curr;
    ++tj_curr;
    tj_st.push(node);
    tj_os[node]=true;
    for(int v:adjlist[node]){
        if(tj_index[v]==-1){
            strongconnect(v);
            tj_lowlink[node]=min(tj_lowlink[node],tj_lowlink[v]);
        }
        else if(tj_os[v]){
            tj_lowlink[node]=min(tj_lowlink[node],tj_index[v]);
        }
    }
    if(tj_lowlink[node]==tj_index[node]){
        int w;
        do{
            w=tj_st.top();
            tj_st.pop();
            tj_os[w]=false;
            scc_index[w]=tj_scc_ct;
        }
        while(w!=node);
        ++tj_scc_ct;
    }
}
void tarjan(){
    fill_n(tj_index,n,-1);
    fill_n(tj_os,n,false);
    while(!tj_st.empty())tj_st.pop();
    tj_curr=tj_scc_ct=0;
    for(int i=0;i<n;++i)
        if(tj_index[i]==-1)strongconnect(i);
}
