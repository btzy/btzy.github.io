// O(V+E)
// find articulation points of an undirected graph
// assumes that graph is connected
// by right it is okay if graph contains
//   self edges or duplicate edges
#define MAX_N 1000000
#include <algorithm>
#include <vector>
using namespace std;
// input:
int n=MAX_N;
vector<int> adjlist[MAX_N];
// output:
vector<int> art_points;

bool visited[MAX_N];
int dfs_order[MAX_N];
int dfs_low[MAX_N];
int dfs_curr;
int ap_dfs(int index){
    visited[index]=true;
    dfs_low[index]=dfs_order[index]=dfs_curr++;
    bool is_ap=false;
    for(int x:adjlist[index]){
        if(!visited[x]){
            int res=ap_dfs(x);
            dfs_low[index]=min(dfs_low[index],res);
            if(res>=dfs_order[index])is_ap=true;
        }
        else{
            dfs_low[index]=min(dfs_low[index],dfs_order[x]);
            if(index==0)is_ap=true; // special case for root
        }
    }
    if(is_ap){
        art_points.emplace_back(index);
    }
    return dfs_low[index];
}
void find_articulation_points(){
    fill_n(visited,n,false);
    art_points.clear();
    dfs_curr=0;
    ap_dfs(0);
}
