// lazy segment tree
// range update range query
#include <algorithm>
#include <utility>
using namespace std;
// depth = N means that there is 2^N leaf nodes
// int may be changed to another type
// T = current value, U = value pending propagation
template <typename T, size_t Depth, typename U>
struct segmenttree_lazy{
    // lazy param of node x has not been applied to node x and all nodes below it
    pair<T,U> arr[1<<(Depth+1)];
    T effective_value(size_t index, size_t rb, size_t re){
        return arr[index].first+arr[index].second*(re-rb); // combiner for lazy value with real value
    }
    void propagate(size_t index, size_t rb, size_t re){
        auto prop_val=arr[index].second; // propagation function...
        arr[index].first=effective_value(index,rb,re);
        arr[index].second=0;
        arr[index<<1].second+=prop_val;
        arr[(index<<1)+1].second+=prop_val;
    }
    void update(size_t index, size_t rb, size_t re, size_t ib, size_t ie, int val){
        if(rb==ib&&re==ie){
            arr[index].second+=val; // update lazy storage
            return;
        }
        propagate(index,rb,re);
        size_t rm=(rb+re)>>1;
        if(ib<rm)update(index<<1,rb,rm,ib,min(rm,ie),val); // transformation for children
        if(rm<ie)update((index<<1)+1,rm,re,max(ib,rm),ie,val); // transformation for children
        arr[index].first=effective_value(index<<1,rb,rm)+effective_value((index<<1)+1,rm,re); // coalesce function
    }
    void update(size_t indexbegin, size_t indexend, int val){
        update(1,0,1<<Depth,indexbegin,indexend,val);
    }
    // past-the-end
    int query(size_t index, size_t rb, size_t re, size_t ib, size_t ie){
        if(rb==ib&&re==ie){
            return effective_value(index,rb,re);
        }
        propagate(index,rb,re);
        int ret=0; // additive identity
        size_t rm=(rb+re)>>1;
        if(ib<rm)ret+=query(index<<1,rb,rm,ib,min(rm,ie)); // coalesce function
        if(rm<ie)ret+=query((index<<1)+1,rm,re,max(ib,rm),ie); // coalesce function
        return ret;
    }
    // past-the-end
    int query(size_t indexbegin, size_t indexend){
        return query(1,0,1<<Depth,indexbegin,indexend);
    }
};
