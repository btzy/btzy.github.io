/*
Fast exponentiation library O(log n)

How to use:
usual version:  fastexp(base, exponent) -> answer
modulo version:  fastexp(base, exponent, modulo) -> answer
*/

#ifndef __cpp_lib_void_t
template<typename... Ts> struct make_void { typedef void type;};
template<typename... Ts> using void_t = typename make_void<Ts...>::type;
#else
using std::void_t;
#endif

template <typename T, typename = void>
struct multiplicative_identity_t {
    T operator()() const{
        return T(1);
    }
};

template <typename T>
struct multiplicative_identity_t<T, void_t<decltype(T::multiplicative_identity())>> {
    T operator()() const{
        return T::multiplicative_identity();
    }
};

template <typename T, typename E>
T fastexp(T base, E exp) {
    T ans=multiplicative_identity_t<T>()();
    for(;exp>0;exp>>=1,base*=base){
        if(exp&1)ans*=base;
    }
    return ans;
}
template <typename T, typename E>
T fastexp(T base, E exp, T mod) {
    T ans=multiplicative_identity_t<T>()();
    for(;exp>0;exp>>=1,base=(base*base)%mod){
        if(exp&1){
            ans*=base;
            ans%=mod;
        }
    }
    return ans;
}

