#include <iostream>
#include <istream>
#include <ostream>
#include <utility>

template <typename T, T MOD>
class modint{
private:
    T val;
public:
    modint():val(){}
    modint(const modint& other):val(other.val){}
    modint(modint&& other):val(std::move(other.val)){}
    modint(const T& t):val(t){
        val%=MOD;
        val+=MOD;
        val%=MOD;
    }
    modint(T&& t):val(std::move(t)){
        val%=MOD;
        val+=MOD;
        val%=MOD;
    }
    modint& operator=(const modint& other){
        val=other.val;
        return *this;
    }
    modint& operator=(modint&& other){
        val=std::move(other.val);
        return *this;
    }
    modint& operator=(const T& t){
        val=t;
        val%=MOD;
        val+=MOD;
        val%=MOD;
        return *this;
    }
    modint& operator=(T&& t){
        val=std::move(t);
        val%=MOD;
        val+=MOD;
        val%=MOD;
        return *this;
    }
    explicit operator T() const {
        return val;
    }
    modint& operator+=(const modint& other){
        val+=other.val;
        val%=MOD;
        return *this;
    }
    modint& operator-=(const modint& other){
        val+=MOD-other.val;
        val%=MOD;
        return *this;
    }
    modint& operator*=(const modint& other){
        val*=other.val;
        val%=MOD;
        return *this;
    }
    modint operator+(const modint& other) const {
        modint ret=*this;
        ret+=other;
        return ret;
    }
    modint operator-(const modint& other) const {
        modint ret=*this;
        ret-=other;
        return ret;
    }
    modint operator*(const modint& other) const {
        modint ret=*this;
        ret*=other;
        return ret;
    }
    modint operator+() const {
        return *this;
    }
    modint operator-() const {
        modint ret=*this;
        ret.val=(MOD-ret.val)%MOD;
        return ret;
    }
    modint& operator++() {
        ++val;
        val%=MOD;
        return *this;
    }
    modint operator++(int) {
        modint ret=*this;
        ++(*this);
        return ret;
    }
    modint& operator--() {
        --val;
        val+=MOD;
        val%=MOD;
        return *this;
    }
    modint operator--(int) {
        modint ret=*this;
        --(*this);
        return ret;
    }
    bool operator==(const modint& other) const {
        return val==other.val;
    }
    bool operator!=(const modint& other) const {
        return !(*this==other);
    }
    bool operator<(const modint& other) const {
        return val<other.val;
    }
    bool operator>=(const modint& other) const {
        return !(*this<other);
    }
    bool operator>(const modint& other) const {
        return val>other.val;
    }
    bool operator<=(const modint& other) const {
        return !(*this>other);
    }
    friend std::istream& operator>>(std::istream& in, modint& x) {
        T t;
        std::istream& ret=(in>>t);
        x=t;
        return ret;
    }
    friend std::ostream& operator<<(std::ostream& out, const modint& x) {
        return out<<x.val;
    }
};

using namespace std;
int main(){
    modint<long long, 1000000007> lm = 45;
    lm=lm+(1000000007-46);
    cout<<lm<<endl;
}
