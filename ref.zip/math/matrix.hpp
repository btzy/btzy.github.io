/*
Matrix library.
Supports addition, subtraction, multiplication via operator overloading.
To get element in matrix, use "mat(row, col)" syntax.
Additive and multiplicative identity aware.

Get additive identity: additive_identity_t<T>()();
Get multiplicative identity: multiplicative_identity_t<T>()();
Will fallback on 0 and 1 respectively.
*/

#include <algorithm>
#include <utility>
#include <type_traits>

template <typename ...T>
int dummy(const T& ...){return 0;}

template <typename Callback, typename InIt1, typename ...InIt>
inline Callback each(Callback callback, InIt1 first1, InIt1 last1, InIt ...first){
    for(; first1 != last1; ++first1, dummy((++first)...)){
        callback(*first1, (*first)...);
    }
    return callback;
}

#ifndef __cpp_lib_void_t
template<typename... Ts> struct make_void { typedef void type;};
template<typename... Ts> using void_t = typename make_void<Ts...>::type;
#else
using std::void_t;
#endif

template <typename T, typename = void>
struct additive_identity_t {
    T operator()() const{
        return T(0);
    }
};

template <typename T>
struct additive_identity_t<T, void_t<decltype(T::additive_identity())>> {
    T operator()() const{
        return T::additive_identity();
    }
};

template <typename T, typename = void>
struct multiplicative_identity_t {
    T operator()() const{
        return T(0);
    }
};

template <typename T>
struct multiplicative_identity_t<T, void_t<decltype(T::multiplicative_identity())>> {
    T operator()() const{
        return T::multiplicative_identity();
    }
};



template <typename T, size_t ROWS, size_t COLS>
class matrix{
private:
    T val[ROWS*COLS];
public:
    enum {
        SIZE = ROWS * COLS
    };
    matrix():val(){}
    matrix(const matrix& other){
        std::copy(other.val,other.val+SIZE,val);
    }
    matrix(matrix&& other){
        std::move(other.val,other.val+SIZE,val);
    }
    matrix& operator=(const matrix& other){
        std::copy(other.val,other.val+SIZE,val);
        return *this;
    }
    matrix& operator=(matrix&& other){
        std::move(other.val,other.val+SIZE,val);
        return *this;
    }
    matrix& operator+=(const matrix& other){
        each([](T& t, const T& u){
            t+=u;
        },val,val+SIZE,other.val);
        return *this;
    }
    matrix& operator-=(const matrix& other){
        each([](T& t, const T& u){
            t-=u;
        },val,val+SIZE,other.val);
        return *this;
    }
    matrix operator+(const matrix& other) const {
        matrix ret=*this;
        ret+=other;
        return ret;
    }
    matrix operator-(const matrix& other) const {
        matrix ret=*this;
        ret-=other;
        return ret;
    }
    template <size_t LENGTH>
    matrix<T, ROWS, LENGTH> operator*(const matrix<T, COLS, LENGTH>& other) const {
        matrix<T, ROWS, LENGTH> ret;
        for(size_t i=0;i!=ROWS;++i){
            for(size_t j=0;j!=LENGTH;++j){
                ret.val[i*COLS+j]=additive_identity_t<T>()();
                for(size_t k=0;k!=COLS;++k){
                    ret.val[i*COLS+j]+=val[i*COLS+k]*other.val[k*COLS+j];
                }
            }
        }
        return ret;
    }
    template <typename = typename std::enable_if<ROWS==COLS>::type>
    matrix& operator*=(const matrix& other){
        (*this)=(*this)*other;
        return *this;
    }
    matrix operator+() const {
        return *this;
    }
    matrix operator-() const {
        matrix ret=*this;
        each([](T& t){
            t=-t;
        },ret.val,ret.val+SIZE);
        return ret;
    }
    bool operator==(const matrix& other) const {
        return std::equal(val,val+SIZE,other.val);
    }
    bool operator!=(const matrix& other) const {
        return !(*this==other);
    }
    T& operator()(size_t i, size_t j){
        return val[i*COLS+j];
    }
    const T& operator()(size_t i, size_t j)const{
        return val[i*COLS+j];
    }
    static matrix additive_identity(){
        matrix ret;
        std::fill(ret.val,ret.val+SIZE,additive_identity_t<T>()());
        return ret;
    }

    template <typename = typename std::enable_if<ROWS==COLS>::type>
    static matrix multiplicative_identity(){
        matrix ret;
        std::fill(ret.val,ret.val+SIZE,additive_identity_t<T>()());
        for(size_t i=0;i!=ROWS;++i){
            ret.val[i*COLS+i]=multiplicative_identity_t<T>()();
        }
        return ret;
    }
};
