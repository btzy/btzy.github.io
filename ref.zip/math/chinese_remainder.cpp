/*
Chinese remainder theorem: find smallest non-negative integer x such that
  x % mod[i] == residue[i]
  for all 1 <= i <= n

How to use: see main() function.
*/

#include <iterator>

template <typename T>
T mul_inv(T a, T b)
{
	T b0 = b, t, q;
	T x0 = 0, x1 = 1;
	if (b == 1) return 1;
	while (a > 1) {
		q = a / b;
		t = b, b = a % b, a = t;
		t = x0, x0 = x1 - q * x0, x1 = t;
	}
	if (x1 < 0) x1 += b0;
	return x1;
}

template <typename Iter>
typename std::iterator_traits<Iter>::value_type chinese_remainder(Iter modfirst, Iter modlast, Iter residuefirst)
{
	typename std::iterator_traits<Iter>::value_type p, prod = 1, sum = 0;

	for (Iter it=modfirst; it!=modlast; ++it) prod *= *it;

	for (; modfirst!=modlast; ++modfirst, ++residuefirst) {
		p = prod / (*modfirst);
		sum += (*residuefirst) * mul_inv(p, *modfirst) * p;
	}

	return sum % prod;
}

#include <iostream>

int main(void)
{
	int mods[] = { 3, 5, 7 };
	int residues[] = { 2, 3, 2 };


	std::cout<< chinese_remainder(mods, mods+3, residues)<<'\n';
	return 0;
}
