/*
Dynamic version of modint, allows setting modulo at run-time.
modint_dynamic instances should not be made to interact with
  other instances that have different mod.
  There is no protection for this.
It is also not possible to change the mod after construction.

How to use:
modint_dynamic<underlying_type> object(val, mod);
*/

#include <istream>
#include <ostream>
#include <utility>

template <typename T>
class modint_dynamic{
private:
    T val;
    T mod;
public:
    modint_dynamic():val(){}
    modint_dynamic(const modint_dynamic& other):val(other.val),mod(other.mod){}
    modint_dynamic(modint_dynamic&& other):val(std::move(other.val)),mod(std::move(other.mod)){}
    modint_dynamic(const T& t, const T& mod):val(t), mod(mod){
        val%=mod;
        val+=mod;
        val%=mod;
    }
    modint_dynamic(T&& t, const T& mod):val(std::move(t)), mod(mod){
        val%=mod;
        val+=mod;
        val%=mod;
    }
    modint_dynamic& operator=(const modint_dynamic& other){
        val=other.val;
        mod=other.mod;
        return *this;
    }
    modint_dynamic& operator=(modint_dynamic&& other){
        val=std::move(other.val);
        mod=std::move(other.mod);
        return *this;
    }
    modint_dynamic& operator=(const T& t){
        val=t;
        val%=mod;
        val+=mod;
        val%=mod;
        return *this;
    }
    modint_dynamic& operator=(T&& t){
        val=std::move(t);
        val%=mod;
        val+=mod;
        val%=mod;
        return *this;
    }
    explicit operator T() const {
        return val;
    }
    modint_dynamic& operator+=(const modint_dynamic& other){
        val+=other.val;
        val%=mod;
        return *this;
    }
    modint_dynamic& operator-=(const modint_dynamic& other){
        val-=other.val;
        val%=mod;
        val+=mod;
        val%=mod;
        return *this;
    }
    modint_dynamic& operator*=(const modint_dynamic& other){
        val*=other.val;
        val%=mod;
        return *this;
    }
    modint_dynamic operator+(const modint_dynamic& other) const {
        modint_dynamic ret=*this;
        ret+=other;
        return ret;
    }
    modint_dynamic operator-(const modint_dynamic& other) const {
        modint_dynamic ret=*this;
        ret-=other;
        return ret;
    }
    modint_dynamic operator*(const modint_dynamic& other) const {
        modint_dynamic ret=*this;
        ret*=other;
        return ret;
    }
    modint_dynamic operator+() const {
        return *this;
    }
    modint_dynamic operator-() const {
        modint_dynamic ret=*this;
        ret.val=(mod-ret.val)%mod;
        return ret;
    }
    modint_dynamic& operator++() {
        ++val;
        val%=mod;
        return *this;
    }
    modint_dynamic operator++(int) {
        modint_dynamic ret=*this;
        ++(*this);
        return ret;
    }
    modint_dynamic& operator--() {
        --val;
        val+=mod;
        val%=mod;
        return *this;
    }
    modint_dynamic operator--(int) {
        modint_dynamic ret=*this;
        --(*this);
        return ret;
    }
    bool operator==(const modint_dynamic& other) const {
        return val==other.val;
    }
    bool operator!=(const modint_dynamic& other) const {
        return !(*this==other);
    }
    bool operator<(const modint_dynamic& other) const {
        return val<other.val;
    }
    bool operator>=(const modint_dynamic& other) const {
        return !(*this<other);
    }
    bool operator>(const modint_dynamic& other) const {
        return val>other.val;
    }
    bool operator<=(const modint_dynamic& other) const {
        return !(*this>other);
    }
    friend std::istream& operator>>(std::istream& in, modint_dynamic& x) {
        T t;
        std::istream& ret=(in>>t);
        x=t;
        return ret;
    }
    friend std::ostream& operator<<(std::ostream& out, const modint_dynamic& x) {
        return out<<x.val;
    }
};
