// O(V+E)
// find bridges in an undirected graph
// assumes that graph is connected
// bridgeflag, fix_lows - fixes the dfs_low so that all biconnected components have
// the same dfs_low, and it is the lowest index in that component
#define MAX_N 100000
#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator> // for bridgeflag
#include <utility>
using namespace std;
// input:
int n;
vector<int> adjlist[MAX_N];

vector<pair<int,int>> bridges;
vector<bool> bridgeflag[MAX_N];

bool visited[MAX_N];
int dfs_order[MAX_N];
int dfs_low[MAX_N];
int dfs_curr;
int br_dfs(int index,int pr){
    visited[index]=true;
    dfs_low[index]=dfs_order[index]=dfs_curr++;
    for(vector<int>::iterator it=adjlist[index].begin();it!=adjlist[index].end();++it){
        int x=*it;
        if(!visited[x]){
            int res=br_dfs(x,index);
            dfs_low[index]=min(dfs_low[index],res);
            if(res>=dfs_order[x]){
                bridges.emplace_back(index,x);
                bridgeflag[index][distance(adjlist[index].begin(),it)]=true;
                // can be optimized to use a map instead of vector:
                bridgeflag[x][distance(adjlist[x].begin(),find_if(adjlist[x].begin(),adjlist[x].end(),[index](const int y){return y==index;}))]=true;
            }
        }
        else if(x!=pr){
            dfs_low[index]=min(dfs_low[index],dfs_order[x]);
        }
    }
    return dfs_low[index];
}
void fix_lows(int index,int low){
    visited[index]=true;
    dfs_low[index]=low;
    for(vector<int>::iterator it=adjlist[index].begin();it!=adjlist[index].end();++it){
        int x=*it;
        if(!visited[x]&&!bridgeflag[index][distance(adjlist[index].begin(),it)]){
            fix_lows(x,low);
        }
    }
}
void find_bridges(){
    fill_n(visited,n,false);
    bridges.clear();
    for(int i=0;i<n;++i){
        bridgeflag[i].assign(adjlist[i].size(),false);
        bridgeflag[i].shrink_to_fit();
    }
    dfs_curr=0;
    for(int i=0;i<n;++i)
        if(!visited[i])br_dfs(i,i);
    fill_n(visited,n,false);
    for(int i=0;i<n;++i)
        if(!visited[i])fix_lows(i,i);
    for(int i=0;i<n;++i){
        bridgeflag[i].clear();
    }
}
