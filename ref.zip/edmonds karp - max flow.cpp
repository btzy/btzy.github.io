// O(V^3*E)
// define the MAX_N correctly
// for directed graph, the opposite edge is 0
// for undirected graph, both edges same weight
#define MAX_N 200
#include <cstdio>
#include <vector>
#include <algorithm>
#include <climits>
#include <queue>
using namespace std;

int res[MAX_N][MAX_N],mf,f,s,t;// s=source, t=end, mf=answer(max flow)
vector<int> p;

void augment(int v, int m){
    if(v==s){f=m;return;}
    else if(p[v]!=-1){
        augment(p[v],min(m,res[p[v]][v]));
        res[p[v]][v]-=f;
        res[v][p[v]]+=f;
    }
}

int main(){
    // set res,s,t;

    mf=0;
    while(true){
        f=0;
        vector<int> dist(MAX_N,INT_MAX);
        dist[s]=0;
        queue<int> q;
        q.emplace(s);
        p.assign(MAX_N,-1);
        while(!q.empty()){
            int u=q.front();q.pop();
            if(u==t)break;
            for(int v=0;v<MAX_N;++v){
                if(res[u][v]>0&&dist[v]==INT_MAX){
                    dist[v]=dist[u]+1;
                    q.push(v);
                    p[v]=u;
                }
            }
        }
        augment(t,INT_MAX);
        if(f==0)break;
        mf+=f;
    }
    printf("%d\n",mf);
}
