/*
Search for needle in haystack.
Returns the list of occurrences of needle in haystack (zero-based).
*/

#include <vector>
#include <iostream>
#include <string>
using namespace std;

vector<int> kmp(const string &needle, const string &haystack) {
  vector<int> ret;
  int m = needle.size();
  vector<int> border(m + 1);
  border[0] = -1;
  for (int i = 0; i < m; ++i) {
    border[i+1] = border[i];
    while (border[i+1] > -1 and needle[border[i+1]] != needle[i]) {
      border[i+1] = border[border[i+1]];
    }
    border[i+1]++;
  }

  int n = haystack.size();
  int seen = 0;
  for (int i = 0; i < n; ++i){
    while (seen > -1 and needle[seen] != haystack[i]) {
      seen = border[seen];
    }
    if (++seen == m) {
      ret.push_back(i - m + 1);
	  seen = border[m];
    }
  }
  return ret;
}

int main(){
    ios_base::sync_with_stdio(false);
    int _x;
    while(cin>>_x){
        string needle, haystack;
        cin>>needle>>haystack;
        const vector<int>& ans=kmp(needle, haystack);
        for(int x:ans){
            cout<<x<<'\n';
        }
        cout<<'\n';
    }
}
