// O(E*sqrt(V))
// for unweighted undirected bipartite matching
// MCBM = max independent (edge) set = min vertex cover (for bipartite graphs)
// min path cover on DAG = n - MCBM:
// U: each vertex with outgoing edges only
// V: each vertex with incoming edges only (total 2*n vertices)
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
using namespace std;
int sizeU,sizeV; // the size of the partitions, initialized already
vector<vector<int>> adjU; // adjlist, initialized already

vector<int> pairU,pairV; // the index of the corresponding matching node, or -1
int* distU;
bool mcbm_bfs(){
    queue<int> q;
    for(int i=0;i<sizeU;++i){
        if(pairU[i]==-1){
            distU[i]=0;
            q.emplace(i);
        }
        else{
            distU[i]=INT_MAX;
        }
    }
    distU[-1]=INT_MAX;
    while(!q.empty()){
        int u=q.front();
        q.pop();
        if(distU[u]<distU[-1]){
            for(int v:adjU[u]){
                if(distU[pairV[v]]==INT_MAX){
                    distU[pairV[v]]=distU[u]+1;
                    q.emplace(pairV[v]);
                }
            }
        }
    }
    return distU[-1]!=INT_MAX;
}

bool mcbm_dfs(int u){
    if(u!=-1){
        for(int v:adjU[u]){
            if(distU[pairV[v]]==distU[u]+1&&mcbm_dfs(pairV[v])){
                pairV[v]=u;
                pairU[u]=v;
                return true;
            }
        }
        return false;
    }
    return true;
}

unsigned do_mcbm(){
    pairU.assign(sizeU,-1);
    pairV.assign(sizeV,-1);
    distU=new int[sizeU+1];
    ++distU;
    unsigned ct=0;
    while(mcbm_bfs()){
        for(int i=0;i<sizeU;++i){
            if(pairU[i]==-1&&mcbm_dfs(i))++ct;
        }
    }
    --distU;
    delete[] distU;
    return ct;
}

int main(){
    int p;
    scanf("%d%d%d",&sizeU,&sizeV,&p);
    adjU.resize(sizeU);
    for(int i=0;i<p;++i){
        int a,b;
        scanf("%d%d",&a,&b);
        adjU[a].emplace_back(b);
    }
    printf("%d\n",do_mcbm());
}
