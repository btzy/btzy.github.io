#include "bits/stdc++.h"
using namespace std;
const int secret = -99999999;
struct node{
    int val;
    int pre;
    int suf;
    int sum;
    int ans;
    int add;
    int maxx;
    bool lazy;
    int siz;
    int pri;
    node* left;
    node* right;
    node(int key = 0){
        val = key;
        pre = key;
        suf = key;
        sum = key;
        ans = key;
        maxx = key;
        add = secret;
        lazy = 0;
        siz = 1;
        pri = rand();
        left = NULL;
        right = NULL;
    }
};
int size(node* tree){
    if(tree){
        return tree -> siz;
    }
    return 0;
}
int value(node* tree){
    if(tree){
        return tree -> val;
    }
    return 0;
}
int prefix(node* tree){
    if(tree){
        return tree -> pre;
    }
    return 0;
}
int suffix(node* tree){
    if(tree){
        return tree -> suf;
    }
    return 0;
}
int sum(node* tree){
    if(tree){
        return tree -> sum;
    }
    return 0;
}
int answer(node* tree){
    if(tree){
        return tree -> ans;
    }
    return secret;
}
int add(node* tree){
    if(tree){
        return tree -> add;
    }
    return secret;
}
bool lazy(node* tree){
    if(tree){
        return tree -> lazy;
    }
    return 0;
}
int maxx(node* tree){
    if(tree){
        return tree -> maxx;
    }
    return secret;
}
void push(node* &tree){
    if(lazy(tree)){
        swap(tree -> left , tree -> right);
        swap(tree -> pre , tree -> suf);
        if(tree -> left){
            tree -> left -> lazy ^= 1;
        }
        if(tree -> right){
            tree -> right -> lazy ^= 1;
        }
        tree -> lazy = 0;
    }
    if(add(tree) != secret){
        tree -> pre = max(add(tree) , add(tree) * size(tree));
        tree -> suf = max(add(tree) , add(tree) * size(tree));
        tree -> sum = add(tree) * size(tree);
        tree -> ans = max(tree -> sum , add(tree));
        tree -> val = add(tree);
        tree -> maxx = add(tree);
        if(tree -> left){
            tree -> left -> add = add(tree);
        }
        if(tree -> right){
            tree -> right -> add = add(tree);
        }
        tree -> add = secret;
    }
}
void upd(node* &tree){
    if(tree){
        push(tree);
        if(tree -> left){
            push(tree -> left);
        }
        if(tree -> right){
            push(tree -> right);
        }
        tree -> siz = size(tree -> left) + 1 + size(tree -> right);
        tree -> sum = value(tree) + sum(tree -> left) + sum(tree -> right);
        tree -> ans = max(max(answer(tree -> left) , answer(tree -> right)) , max(0 , suffix(tree -> left)) + value(tree) + max(0 , prefix(tree -> right)));
        tree -> pre = max(prefix(tree -> left) , sum(tree -> left) + value(tree) + max(0 , prefix(tree -> right)));
        tree -> suf = max(suffix(tree -> right) , max(0 , suffix(tree -> left)) + value(tree) + sum(tree -> right));
        tree -> maxx = max(max(maxx(tree -> left) , maxx(tree -> right)) , tree -> val);
    }
}
void split(node* tree , node* &l , node* &r , int idx , int lcount){
    if(!tree){
        l = NULL;
        r = NULL;
        return;
    }
    push(tree);
    int newidx = 1 + lcount + size(tree -> left);
    if(newidx <= idx){
        split(tree -> right , tree -> right , r , idx , newidx);
        l = tree;
    }
    else{
        split(tree -> left , l , tree -> left , idx , lcount);
        r = tree;
    }
    upd(tree);
}
void merge(node* &tree , node* l , node* r){
    if(!l || !r){
        tree = l ? l : r;
    }
    else if(l -> pri > r -> pri){
        push(l);
        merge(l -> right , l -> right , r);
        tree = l;
    }
    else{
        push(r);
        merge(r -> left , l , r -> left);
        tree = r;
    }
    upd(tree);
}
node* root = NULL;
void insert(int pos , int key){
    node* temp1 = NULL;
    node* temp2 = NULL;
    node* temp3 = new node(key);
    split(root , temp1 , temp2 , pos - 1 , 0);
    merge(temp1 , temp1 , temp3);
    merge(root , temp1 , temp2);
}
void erase(int pos , int cnt){
    node* temp1 = NULL;
    node* temp2 = NULL;
    node* temp3 = NULL;
    split(root , temp1 , temp2 , pos - 1 , 0);
    split(temp2 , temp2 , temp3 , cnt , 0);
    merge(root , temp1 , temp3);
}
int sum(int l , int r){
    node* temp1 = NULL;
    node* temp2 = NULL;
    node* temp3 = NULL;
    node* temp4 = NULL;
    split(root , temp1 , temp2 , l - 1 , 0);
    split(temp2 , temp3 , temp4 , r - l + 1 , 0);
    int ans = sum(temp3);
    merge(temp2 , temp3 , temp4);
    merge(root , temp1 , temp2);
    return ans;
}
void reverse(int l , int r){
    node* t4 = NULL;
    node* t3 = NULL;
    node* t2 = NULL;
    node* t1 = NULL;
    split(root , t3 , t4 , r , 0);
    split(t3 , t1 , t2 , l - 1 , 0);
    if(t2){
        t2 -> lazy ^= 1;
        upd(t2);
    }
    merge(t3 , t1 , t2);
    merge(root , t3 , t4);
}
void modify(int l , int r , int val){
    node* t4 = NULL;
    node* t3 = NULL;
    node* t2 = NULL;
    node* t1 = NULL;
    split(root , t3 , t4 , r , 0);
    split(t3 , t1 , t2 , l - 1 , 0);
    if(t2){
        t2 -> add = val;
    }
    merge(t3 , t1 , t2);
    merge(root , t3 , t4);   
}
void print(node* tree){
    if(tree){
        push(tree);
        print(tree -> left);
        cout << tree -> val << " ";
        print(tree -> right);
        upd(tree);
    }
}
void insert(node* tree , int pos){
    node* t1 = NULL;
    node* t2 = NULL;
    split(root , t1 , t2 , pos , 0);
    merge(t1 , t1 , tree);
    merge(root , t1 , t2);
}
int n , q;
int pos , x , y;
char tmp[20];
int main(){
    scanf("%d %d" , &n , &q);
    for(int i = 1 ; i <= n ; ++i){
        scanf("%d" , &x);
        merge(root , root , new node(x));
    }
    while(q--){
        scanf("%s" , tmp);
        if(tmp[0] == 'I'){
            scanf("%d %d" , &pos , &y);
            node* tmp = NULL;
            for(int i = 1 ; i <= y ; ++i){
                scanf("%d" , &x);
                merge(tmp , tmp , new node(x));
            }
            insert(tmp , pos);
        }
        else if(tmp[0] == 'D'){
            scanf("%d %d" , &pos , &y);
            erase(pos , y);
        }
        else if(tmp[0] == 'R'){
            scanf("%d %d" , &pos , &y);
            x = pos;
            y = pos + y - 1;
            reverse(x , y);
        }
        else if(tmp[0] == 'G'){
            scanf("%d %d" , &pos , &y);
            x = pos;
            y = pos + y - 1;
            printf("%d\n" , sum(x , y));
        }
        else if(tmp[2] == 'X'){
            push(root);
            int anss = answer(root);
            if(anss == 0){
                anss = maxx(root);
            }
            printf("%d\n" , anss);
        }
        else{
            scanf("%d %d %d" , &pos , &y , &x);
            y = pos + y - 1;
            modify(pos , y , x);   
        }
    }
}
