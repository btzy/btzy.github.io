char s[MAXN*2 + 1];  //input string, will be twiced by min_shift

// returns vector<int> of begins of prime strings
// string should have zero simbol at end.
vector<int> duval(){
  vector<int> res;
  int len = strlen(s) + 1; // zero used here
  int start = 0, mid = 1, cur = 0;
  res.pb(0);
  for (int i = 0; i < len; i++){
    if (s[i] == s[cur]){
      cur++;
      if (cur == mid) cur = start;
    } else if (s[i] > s[cur]){
      mid = i+1;
      cur = start;
    } else if (s[i] < s[cur]){
      int temp = mid - start;
      while (start + temp <= i){
        start += temp;
        res.pb(start);
      }
      i = cur = start;
      mid = start + 1;
    }
    else
      assert(false);
  }
  return res;
}

int min_shift(){
  int len = strlen(s);
  memcpy(s+len,s,sizeof(char)*len);
  s[2*len] = 0;
  vector<int> v = duval();
  s[len] = 0;
  for (int i = 0; i < (int)v.size(); i++)
    if (i == (int)v.size()-1 || v[i+1] >= len)
      return v[i];
  assert(false);
}