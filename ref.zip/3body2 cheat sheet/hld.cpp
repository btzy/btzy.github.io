int head[N], int chain[N], chno = 0, sz[N], D[N], pos[N], H = 0, P[N], rpos[N];
void dfs(int v, int p, int dep) {
	sz[v] = 1;
	D[v] = dep;
	P[v] = p;
	for (int i = 0; i < adj[v].size(); ++i) {
		int u = adj[v][i];
		if (u == p) continue;
		dfs(u, v, dep + 1);
		sz[v] += sz[u];
	}
}
void hld(int v, int p) {
	if (head[chno] == -1) {
		head[chno] = v;
	}
	chain[v] = chno;
	pos[v] = H++;
	rpos[H - 1] = function(v);
	int cind = -1;
	for (int i = 0; i < adj[v].size(); ++i) {
		int u = adj[v][i];
		if (u != p && (cind == -1 || sz[cind] < sz[u])) cind = u;
	}
	if (cind != -1) hld(cind, v);
	rep (i, adj[v].size()) {
		int u = adj[v][i];
		if (u != p && u != cind) {
			chno++;
			hld(u, v);
		}
	}
}
int lca(int u, int v) {
	while (chain[v] != chain[u]) {
		if (D[head[chain[v]]] > D[head[chain[u]]]) {
			v = P[head[chain[v]]];
		}
	}
	if (D[v] > D[u]) return u;
	else return v;
}
void init(int l, int r, int i) {
	if (l == r) {
		T[i] = rpos[l - 1];
		return;
	}
	int mid = (l + r) / 2;
	init(l, mid, l(i));
	init(mid + 1, r, r(i));
	T[i] = min(T[l(i)], T[r(i)]);
}
void modify(int l, int r, int i, int v, int x) {
	if (l == r) {
		T[i] = x;
		return;
	}
	int mid = (l + r) / 2;
	if (v <= mid) modify(l, mid , l(i), v, x);
	else modify(mid + 1, r, r(i), v, x);
	T[i] = min(T[l(i)], T[r(i)]);
}
int query(int l, int r, int i, int rl, int rr) {
	if (rl <= l && r <= rr) return T[i];
	if (l > rr || rl > r) return INT_MAX;
	int mid = (l + r) / 2;
	return min(query(l, mid, l(i), rl, rr), query(mid + 1, r, r(i), rl, rr));
}
int query(int x, int p) {
	while (chain[x] != chain[p]) {
		int x = query(0, n - 1, 0, pos[head[chain[x]]], pos[x]);
		x  = P[head[chain[x]]];
	}
	int x = query(0, n -1, 0, pos[p], pos[x]);
}