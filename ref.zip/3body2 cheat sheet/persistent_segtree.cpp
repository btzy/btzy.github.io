#include "bits/stdc++.h"
using namespace std;
const int N = 2e5 + 5;
const int LN = 32;
const int MX = 1e9 + 9;
int n;
int arr[N];
int q;
int l , r;
struct node{
    long long val;
    int left;
    int right;
    node(){
    	val = 0;
    	left = 0;
    	right = 0;
    }
};
node st[N * LN];
int root[N];
int cur = 0;
int dummy;
int newnode(long long val , int left , int right){
	++cur;
	st[cur].val = val;
	st[cur].left = left;
	st[cur].right = right;
	return cur;
}
void insert(int &curnode , int prenode , int l , int r , long long value){
	if(l == r){
		curnode = newnode(st[prenode].val + value , dummy , dummy);
		return;
	}
	int mid = l + r >> 1;
	if(value <= mid){
		curnode = newnode(st[prenode].val + value , dummy , st[prenode].right);
		insert(st[curnode].left , st[prenode].left , l , mid , value);
	}
	else{
		curnode = newnode(st[prenode].val + value , st[prenode].left , dummy);
		insert(st[curnode].right , st[prenode].right , mid + 1 , r , value);
	}
}
long long query(int l , int r , int rnode , int lnode , int ql , int qr){
	if(l > qr || r < ql){
		return 0;
	}
	if(l >= ql && r <= qr){
		return st[rnode].val - st[lnode].val;
	}
	int mid = l + r >> 1;
	return query(l , mid , st[rnode].left , st[lnode].left , ql , qr) + query(mid + 1 , r , st[rnode].right , st[lnode].right , ql , qr);
}
long long query(int ql , int qr , long long l , long long r){
	if(l >= MX){
		return 0;
	}
	r = min(r , 1LL * MX);
	return query(1 , MX , root[qr] , root[ql - 1] , l , r);
}
void query(int ql , int qr){
	long long sum = 1;
	long long presum = 0;
	while(1){
		long long tmp = query(ql , qr , presum + 1 , sum);
		if(!tmp){
			break;
		}
		presum = sum;
		sum += tmp;
	}
	printf("%lld\n" , sum);
}
int main(){
    scanf("%d %d" , &n , &q);
    for(int i = 1 ; i <= n ; ++i){
        scanf("%d" , arr + i);
    }
    dummy = newnode(0 , 0 , 0);
    root[0] = dummy;
    for(int i = 1 ; i <= n ; ++i){
        insert(root[i] , root[i - 1] , 1 , MX , arr[i]);
    }
    while(q--){
        scanf("%d %d" , &l , &r);
        query(l , r);
    }
}
