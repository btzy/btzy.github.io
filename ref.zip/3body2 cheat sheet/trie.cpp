#include <bits/stdc++.h>
using namespace std;

struct node{
	int val;
	bool exists, leaf;
	node *child[30];
};

node *root = new node;

void insert(string A){
	node *current = root;
	current->val++;
	int len = A.length();
	for(int i = 0; i < len; i++){
		int index = A[i] - 'a';
		if(current->child[index] == NULL){
			current->child[index] = new node;
			current->child[index]->val = 0, current->child[index]->exists = true;
			for(int j = 0; j < 30; j++)	current->child[index]->child[j] = NULL;
		}
		current = current->child[index];
		current->val++;
	}
}

int query(string A){
	node *current = root;
	int tot = current->val;
	int len = A.length();
	for(int i = 0; i < len; i++){
		int index = A[i] - 'a';
		if(current->child[index] != NULL && current->child[index]->exists == true)	current = current->child[index];
		else break;
		tot += current->val;
	}
	return tot;
}

const int N = 30005;

string input[N], temp;
vector<pair<string, int> > Q[N];
map<string, int> M;
int ans[N];

int main(){

	root->val = 0, root->exists = true;

	int n, q, id;
	cin>>n;

	for(int i = 0; i < n; i++){
		cin>>input[i];
		M[input[i]] = i;
	}

	cin>>q;

	for(int i = 0; i < q; i++){
		cin>>temp;
		if(M.find(temp) != M.end())	Q[M[temp]].push_back(make_pair(temp, i));
		else Q[n - 1].push_back(make_pair(temp, i));
	}

	for(int i = 0; i < n; i++){
		insert(input[i]);
		for(int j = 0; j < Q[i].size(); j++){
			temp = Q[i][j].first, id = Q[i][j].second;
			ans[id] = query(temp);
		}
		cout<<i<<endl;
	}

	for(int i = 0; i < q; i++)	cout<<ans[i]<<endl;
	
	return 0;
}