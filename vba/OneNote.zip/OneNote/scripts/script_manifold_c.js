function InitSectionStates()
{
    sectionStatesInitialized = true;
    if (globals == null) globals = GetGlobals();
    // SectionStates has the format:
    //
    //     firstSectionId:state;secondSectionId:state;thirdSectionId:state; ... ;lastSectionId:state
    //
    // where state is either "e" (expanded) or "c" (collapsed)
    
    // get the SectionStates from the previous topics
    var states = Load("SectionStates");

    var start = 0;
    var end;
    var section;
    var state;
    var allCollapsed = true;
    // copy the previous section states to the sectionStates array for the current page
	if (states != null && states != "")
	{
	    allCollapsed = true;
        while (start < states.length)
        {
            end = states.indexOf(":", start);
            
            section = states.substring(start, end);
            
            start = end + 1;
            end = states.indexOf(";", start);
            if (end == -1) end = states.length;
            state = states.substring(start, end);
            sectionStates[section] = state;
    	    allCollapsed = allCollapsed && (state == "c");
    	    start = end + 1;
        }
	}
    
    // now set the state for any section ids in the current document that weren't in previous
	var imgElements = document.getElementsByName("toggleSwitch");
	var i;
	for (i = 0; i < imgElements.length; ++i)
        sectionStates[imgElements[i].id] = GetInitialSectionState(imgElements[i].id, allCollapsed);
}
